from django.urls import path
from dashboard import views

urlpatterns = [
    path('', views.dashboard, name = 'dashboard'),
    path('dashboard/', views.dashboard1, name = 'dashboard1'),
    path('statistics/',views.statistics,name='statistics'),
    path('sample/',views.sample,name='sample')
]

