from django.shortcuts import render
from django.http import HttpRequest, HttpResponse
from datetime import datetime
from dashboard_app.forms import DateSelectionForm, PosFbTypeForm, TypeForm, ProductClassFilterForm, productForm, outletForm,outletForm2
from django.db import connection

from pandas import DataFrame
import plotly.express as px
import plotly.io as pio
import pandas as pd

def posfbtype(postype, selected_date):
    try:
        # Execute query for the selected type and date
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT outletcity, posfbtype "
                "FROM salessummary "
                "WHERE posfbtype = %s AND invcdate::date = %s;", 
                (postype, selected_date)
            )
            product_data = cursor.fetchall()

            # Check if there's any data
            if not product_data:
                return None

            # Create DataFrame
            column_names = [desc[0] for desc in cursor.description]
            df = pd.DataFrame(product_data, columns=column_names)
            
            # Aggregate data
            df_agg = df.groupby('outletcity').size().reset_index(name='count')
            df_agg = df_agg.sort_values('count', ascending=False)
            
            # Create Plotly bar chart
            fig = px.bar(
                df_agg,
                x='outletcity',
                y='count',
                title=f"{postype} Counts by Outlet City on {selected_date}",
                labels={
                    'outletcity': 'City', 
                    'count': f'{postype} Count'
                },
                color='outletcity',
            )
            
            # Customize chart layout
            fig.update_layout(
                xaxis_title="Outlet City",
                yaxis_title=f"Number of {postype} Orders",
                #margin=dict(l=100, r=300, b=50, t=100),
                showlegend =False,
                title=dict(
                    font=dict(size=15),
                    yref='paper',
                    x=0.5, 
                    xanchor='center'
                ),
            )
            
            # Display the chart
            chart = pio.to_html(fig, full_html=False)

            return chart

    except Exception as e:
        print(f"Error in posfbtype function: {e}")
        return None

def status(selected_date,x):
    try:
        # Query database for the relevant data
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT 
                    totalinvc,
                    status, 
                    invcdate::time AS extracted_time, 
                    invcdate::date AS extracted_date 
                FROM salessummary 
                WHERE invcdate::date = %s AND status = %s
                ORDER BY invcdate::time;
                """,
                (selected_date, x)
            )
            data = cursor.fetchall()
            
        # Create DataFrame
        column_names = [desc[0] for desc in cursor.description]
        distribution = pd.DataFrame(data, columns=column_names)

        # Convert extracted_time to proper time format
        distribution['extracted_time'] = pd.to_datetime(
            distribution['extracted_time'], format='%H:%M:%S'
        ).dt.time

        print(distribution)
        # Create area chart
        fig = px.area(
            distribution,
            x='extracted_time',
            y='totalinvc',
            color='status',
            title=f"Sales Summary ({x}) for {selected_date}",
            labels={
                'extracted_time': 'Time',
                'totalinvc': 'Total Invoice',
                'status': 'Status'
            }
        )

        # Improve chart readability
        fig.update_layout(
            xaxis_title='Time',
            yaxis_title='Total Invoice',
            legend_title='Status',
            title=dict(
                    font=dict(size=15),
                    yref='paper',
                    x=0.5, 
                    xanchor='center'
            )
        )

        # Convert Plotly figure to HTML
        plot = pio.to_html(fig, full_html=False)

        return plot

    except Exception as e:
        # Log error details
        print(f"Error in status function: {e}")
        return None


def pos(selected_date):
    if selected_date == None:
        selected_date = '0001-01-01'
    with connection.cursor() as cursor:
        cursor.execute(
            """
            SELECT *
            FROM posopen
            INNER JOIN posopenomdoc
            ON posopen.id = posopenomdoc.posopenid
            INNER JOIN omdoc
            ON omdoc.id = posopenomdoc.omdocid
            INNER JOIN omtran
            ON omtran.omdocid = posopenomdoc.omdocid
            WHERE posopen.sessionclose::date != '0001-01-01' AND omtran.description != 'Testing Rounding' AND omdoc.invcdate::date =%s
            """,
            (selected_date,)
        )
        data = cursor.fetchall()
        column_names = [desc[0] for desc in cursor.description]
        pos = pd.DataFrame(data, columns=column_names)

        df = pos.loc[:, ~pos.columns.duplicated()].copy()
        pos = df.head(5)

        # Pick some features for the sunburst chart
        features = ['posfbtype', 'orderstatus', 'description']

        # Create a sunburst chart
        fig = px.sunburst(
            df, path=features, values='qty', title="Overview in Status and PosfbType under Product Sales Quantity",
        )

        fig.update_layout(
            title=dict(font=dict(size=15), yref='paper'),
        )

        fig.update_layout(showlegend=True)
        
        plot = pio.to_html(fig, full_html=False)

    return pos.to_html(index=False, escape=False), plot


def productclass_detail(selected_date, product_class):
    try:
        # Query database for the relevant data
        with connection.cursor() as cursor: 
            cursor.execute(
                """
                SELECT omdoc.outletid, omdoc.invcdate::date AS extracted_date,
                       productclass.name AS productClassName, omtran.qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                INNER JOIN productclass ON product.productclassid = productclass.id
                WHERE productclass.name = %s AND omdoc.invcdate::date = %s
                """,
                [product_class, selected_date]
            )
            data = cursor.fetchall()
            
            if not data:
                print("No data found for the selected product class and date.")
                return None

            # Create DataFrame
            column_names = [desc[0] for desc in cursor.description]
            df = pd.DataFrame(data, columns=column_names)

            # Map outlet IDs to names
            cursor.execute("SELECT id, name FROM outlet")
            outlet_data = dict(cursor.fetchall())
            df['outlet'] = df['outletid'].map(outlet_data)

            # Aggregate by outlet
            aggregated_data = (
                df.groupby('outlet')
                .size()
                .reset_index(name='count')
                .sort_values('count', ascending=False)
                .reset_index(drop=True)
            )

            # Create bar chart
            fig = px.bar(
                aggregated_data,
                x='outlet',
                y='count',
                title=f"{product_class} Counts by Outlet on {selected_date}",
                labels={'outlet': 'Outlet', 'count': 'Count'},
                color='outlet'
            )

            fig.update_layout(
                showlegend=False,
            )

            # Convert Plotly figure to HTML
            plot = pio.to_html(fig, full_html=False)

            return plot

    except Exception as e:
            # Log error details
            print(f"Error in productclass_detail function: {e}")
            return None

def product_detail(selected_date,product_class):
    try:
        # Query database for the relevant data
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT omdoc.outletid, omdoc.invcdate::date AS extracted_date,
                       product.name AS productName, omtran.qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                WHERE product.name = %s AND omdoc.invcdate::date = %s
                """,
                [product_class, selected_date]
            )
            data = cursor.fetchall()
            
            if not data:
                print("No data found for the selected product and date.")
                return None

            # Create DataFrame
            column_names = [desc[0] for desc in cursor.description]
            df = pd.DataFrame(data, columns=column_names)

            # Map outlet IDs to names
            cursor.execute("SELECT id, name FROM outlet")
            outlet_data = dict(cursor.fetchall())

            df['outlet'] = df['outletid'].map(outlet_data)

            # Aggregate by outlet
            aggregated_data = (
                df.groupby('outlet')
                .size()
                .reset_index(name='count')
                .sort_values('count', ascending=False)
                .reset_index(drop=True)
            )

            # Create bar chart
            fig = px.bar(
                aggregated_data,
                x='outlet',
                y='count',
                title=f"{product_class} Counts <br> by Outlet on {selected_date}",
                labels={'outlet': 'Outlet', 'count': 'Count'},
                color='outlet'
            )

            # Convert Plotly figure to HTML
            plot = pio.to_html(fig, full_html=False)

            return plot

    except Exception as e:
            # Log error details
            print(f"Error in product_detail function: {e}")
            return None
    
def outlet(selected_date, outlet):
    try:
        # Query database for the relevant data
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT omdoc.outletid, omdoc.invcdate::date AS extracted_date,
                    product.name AS productname, omtran.qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                INNER JOIN outlet ON omdoc.outletid = outlet.id
                WHERE outlet.name = %s AND omdoc.invcdate::date = %s
                """,
                [outlet, selected_date]
            )
            data = cursor.fetchall()

            if not data:
                print("No data found for the selected outlet and date.")
                return None

            # Process data into DataFrame
            column_names = [desc[0] for desc in cursor.description]
            df = pd.DataFrame(data, columns=column_names)

            if df.empty:
                print("No data available for aggregation.")
                return None

            # Aggregate data by product name
            df_agg = (
                df.groupby('productname')
                .size()
                .reset_index(name='count')
                .sort_values('count', ascending=False)
                .reset_index(drop=True)
            )

            if df_agg.empty:
                print("No aggregated data for the bar chart.")
                return None

            # Create bar chart
            fig = px.bar(
                df_agg,
                x='productname', 
                y='count',
                title=f"Product Sales Overview for  {outlet} <br> on {selected_date}",
                labels={'productname': 'Product', 'count': 'Count'},
                color='productname'
            )

            fig.update_layout(
                showlegend=False,
                title=dict(
                    font=dict(size=15),
                    yref='paper',
                    x=0.5, 
                    xanchor='center'
                )
            )

            fig.update_xaxes(
                tickangle=45,
            )
            # Convert Plotly figure to HTML
            plot = pio.to_html(fig, full_html=False)

            return plot

    except Exception as e:
        # Log error details
        print(f"Error in outlet function: {e}")
        return None
    
def outlet_productclass(selected_date,outlet):
    try:
        # Query database for the relevant data
        with connection.cursor() as cursor:
            cursor.execute(
                """
               SELECT omdoc.outletid, omdoc.invcdate::date AS extracted_date,
                    productclass.name AS productClassName, omtran.qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                INNER JOIN productclass ON product.productclassid = productclass.id
                INNER JOIN outlet ON omdoc.outletid = outlet.id
                WHERE outlet.name = %s AND omdoc.invcdate::date = %s
                """,
                [outlet, selected_date]
            )
            data = cursor.fetchall()

            if not data:
                print("No data found for the selected outlet and date.")
                return None

            # Process data into DataFrame
            column_names = [desc[0] for desc in cursor.description]
            df = pd.DataFrame(data, columns=column_names)

            if df.empty:
                print("No data available for aggregation.")
                return None

            # Aggregate data by product name
            df_agg = (
                df.groupby('productclassname')
                .size()
                .reset_index(name='count')
                .sort_values('count', ascending=False)
                .reset_index(drop=True)
            )

            if df_agg.empty:
                print("No aggregated data for the bar chart.")
                return None

            # Create bar chart
            fig = px.bar(
                df_agg,
                x='productclassname', 
                y='count',
                title=f"Product Class Sales Overview for  {outlet} on {selected_date}",
                labels={'productclassname': 'Product Class', 'count': 'Count'},
                color='productclassname'
            )

            # Convert Plotly figure to HTML
            plot2 = pio.to_html(fig, full_html=False)

            return plot2

    except Exception as e:
        # Log error details
        print(f"Error in outlet function: {e}")
        return None

def dashboard(request):
    try:
        assert isinstance(request, HttpRequest)
        # Initialize forms
        date_form = DateSelectionForm(request.POST or None)
        pos_form = PosFbTypeForm(request.POST or None)
        productclass_form = ProductClassFilterForm(request.POST or None)
        type_form = TypeForm(request.POST or None)
        product_form = productForm(request.POST or None)
        outlet_form = outletForm(request.POST or None)
        outlet_form2 = outletForm2(request.POST or None)
        
        # Initialize session variables if they don't exist
        if 'selected_date' not in request.session:
            request.session['selected_date'] = '2000-01-01'
        if 'selected_posfbtype' not in request.session:
            request.session['selected_posfbtype'] = None
        if 'selected_type' not in request.session:
            request.session['selected_type'] = None
        if 'selected_productclass' not in request.session:
            request.session['selected_productclass'] = None
        if 'selected_product' not in request.session:
            request.session['selected_product'] =None
        if 'selected_outlet' not in request.session:
            request.session['selected_outlet'] = None
        if 'selected_outlet2' not in request.session:
            request.session['selected_outlet2'] = None

        if request.method == 'POST':
            print("POST data:", request.POST)
            
            # Handle DateSelectionForm
            if 'selected_date' in request.POST and date_form.is_valid():
                selected_date = date_form.cleaned_data['selected_date']
                request.session['selected_date'] = [selected_date]
                print(f"Selected date: {selected_date}")
                
            # Handle PosFbTypeForm
            if 'selected_posfbtype' in request.POST and pos_form.is_valid():
                selected_posfbtype = pos_form.cleaned_data['selected_posfbtype']
                request.session['selected_posfbtype'] = selected_posfbtype
                print(f"Selected POS type: {selected_posfbtype}")
                
            # Handle TypeForm
            if 'selected_type' in request.POST and type_form.is_valid():
                selected_type = type_form.cleaned_data['selected_type']
                request.session['selected_type'] = selected_type
                print(f"Selected type: {selected_type}")

            if 'selected_productclass' in request.POST and productclass_form.is_valid():
                selected_productclass = productclass_form.cleaned_data['selected_productclass']
                request.session['selected_productclass'] = selected_productclass
                print(f"Selected product class: {selected_productclass}")

            if 'selected_product' in request.POST and product_form.is_valid():
                selected_product = product_form.cleaned_data['selected_product']
                request.session['selected_product'] = selected_product
                print(f"Selected product class: {selected_product}")
                
            if 'selected_outlet' in request.POST and outlet_form.is_valid():
                selected_outlet = outlet_form.cleaned_data['selected_outlet']
                request.session['selected_outlet'] = selected_outlet
                print(f"Selected Outlet : {selected_outlet}")

            if 'selected_outlet2' in request.POST and outlet_form2.is_valid():
                selected_outlet2 = outlet_form2.cleaned_data['selected_outlet2']
                request.session['selected_outlet2'] = selected_outlet2
                print(f"Selected Outlet : {selected_outlet2}")

        # Retrieve session data
        selected_date = request.session['selected_date'][0]
        selected_posfbtype = request.session['selected_posfbtype']
        selected_type = request.session['selected_type']
        selected_productclass = request.session['selected_productclass']
        selected_product = request.session['selected_product']
        selected_outlet = request.session['selected_outlet']
        selected_outlet2 =request.session['selected_outlet2']

        print(f"Session data - Date: {selected_date}, POS Type: {selected_posfbtype}, Type: {selected_type} Product Class : {selected_productclass},Product : {selected_product},Outlet ; {selected_outlet}")
        
        # Generate all charts regardless of selection state
        chart1 = posfbtype(selected_posfbtype, selected_date) if selected_date else None
        chart2 = status(selected_date, selected_type) if selected_date else None
        chart3 = productclass_detail(selected_date, selected_productclass) if selected_date  else None
        chart4 = product_detail(selected_date, selected_product) if selected_date  else None
        chart5 = outlet(selected_date,selected_outlet) if selected_date else None
        chart6 = outlet_productclass(selected_date,selected_outlet2) if selected_date else None

        return render(request, 'dashboard.html', {
            'title': 'Dashboard :',
            'message': 'Sales Data Summary.',
            'year': datetime.now().year,
            'date_form': date_form,
            'pos_form': pos_form,
            'type_form': type_form,
            'productclass_form':  productclass_form ,
            'product_form' : product_form,
            'outlet_form' : outlet_form,
            'outlet_form2' : outlet_form2,
            'date': selected_date,
            'chart1': chart1,
            'chart2': chart2,
            'chart3': chart3,
            'chart4': chart4,
            'chart5': chart5,
            'chart6' : chart6,
        })
    except Exception as e:
        print(f"Error in dashboard view: {e}")
        return render(request, 'error.html', {
            'message': f"An error occurred: {e}",
        })

def postfbtype_overview(selected_date):
    try:
        # Execute query to fetch the count of records grouped by 'posfbtype' for the given date
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT posfbtype, count(*) AS count 
                FROM salessummary 
                WHERE invcdate::date = %s 
                GROUP BY posfbtype;
                """, 
                (selected_date,)
            )
            data = cursor.fetchall()
            
            # Extract column names and create a DataFrame
            column_names = [desc[0] for desc in cursor.description]
            product = pd.DataFrame(data, columns=column_names)
            
            # Sort values for better visualization
            df_count = product.sort_values('count', ascending=True).reset_index(drop=True)

            # Plot the horizontal bar chart
            fig_count = px.bar(
                df_count,
                x='count',
                y='posfbtype',
                orientation='h',  # Horizontal bar chart
                title=f"POS/FB Type on {selected_date}",
                text='count'
            )
            fig_count.update_traces(textposition='outside')  # Display count outside bars
            fig_count.update_layout(yaxis=dict(title="Order Type"), xaxis=dict(title="Count"))

            # Convert the figure to HTML
            chart = pio.to_html(fig_count, full_html=False)
            return chart

    except (pg.Error, Exception) as e:
        print(f"Error in product function: {e}")
        return None

def payment(request):
    try:
        # Fetch tender type data
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM tendertype")
            tender_data = cursor.fetchall()
            if not tender_data:
                return render(request, 'home.html', {'warning': "No tender type data available."})

            # Create a DataFrame for tender types
            column_names = [desc[0] for desc in cursor.description]
            tender_df = DataFrame(tender_data, columns=column_names)
            list_of_payment = dict(zip(tender_df['id'], tender_df['name']))

            # Fetch payment data
            cursor.execute("""
                SELECT tendertypeid, COUNT(*) AS count 
                FROM ompayment 
                WHERE tendertypeid IS NOT NULL 
                GROUP BY tendertypeid 
                ORDER BY count DESC
            """)
            payment_data = cursor.fetchall()
            if not payment_data:
                return render(request, 'home.html', {'warning': "No payment data available."})

            # Create a DataFrame for payment data
            column_names = [desc[0] for desc in cursor.description]
            payment_df = DataFrame(payment_data, columns=column_names)

            # Map tender type names to payment data
            payment_df['tendertypename'] = payment_df['tendertypeid'].map(list_of_payment).fillna("Unknown")

            # Create a pie chart
            fig = px.pie(
                payment_df,
                values='count',
                names='tendertypename',
                title="Payment Type Distribution",
                hole=0.3,
            )
            fig.update_traces(textposition='inside', textinfo='percent+label')

            # Convert chart to HTML
            chart_html = pio.to_html(fig, full_html=False)

            data = payment_df.to_html(index=False)
            return chart_html
            # return render(request, 'home.html', {'chart': chart_html, 'data': payment_df.to_html(index=False)})
    except Exception as e:
        error_message = f"An error occurred: {e}"
        return render(request, 'home.html', {'error': error_message})


def product(selected_date):
    try:
        with connection.cursor() as cursor:
            cursor.execute(
                "WITH t1 AS ( "
                "SELECT omdoc.id, totalinvc, to_char(invcdate, 'YYYY-MM-DD') AS extracted_date, description, qty "
                "FROM omdoc "
                "JOIN omtran USING (id)"
                ") "
                "SELECT totalinvc, extracted_date, description, qty "
                "FROM t1 "
                "WHERE description != 'Testing Rounding' AND extracted_date = %s;",
                (selected_date,)
            )
            data = cursor.fetchall()
            
            column_names = [desc[0] for desc in cursor.description]
            product = pd.DataFrame(data, columns=column_names)

            # Create Plotly bar chart for description vs qty and totalinvc
            if not product.empty:
                fig = px.bar(
                    product.melt(id_vars=['description'], value_vars=['qty', 'totalinvc']),
                    x='value',
                    y='description',
                    color='variable',
                    title=f"Product Quantity and Sales on {selected_date}",
                    labels={
                        'description': 'Product', 
                        'value': 'Quantity / Sales'
                    },
                    orientation="h"
                )
                
                # Customize chart layout
                fig.update_layout(
                    xaxis_title="Quantity / Sales",
                    yaxis_title="Product"
                )
                
                chart1 = pio.to_html(fig, full_html=False)
                return chart1
            else:
                return ""

    except (pg.Error, Exception) as e:
        print(f"Error in product function: {e}")
        return None


def status_overview(selected_date):
    try:
        # Execute query to fetch the count of records grouped by 'status' for the given date
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT status, count(*) AS count 
                FROM salessummary 
                WHERE invcdate::date = %s 
                GROUP BY status;
                """,
                (selected_date,)
            )
            status_data = cursor.fetchall()
            
            # Extract column names and create a DataFrame
            column_names = [desc[0] for desc in cursor.description]
            df_agg = pd.DataFrame(status_data, columns=column_names)
            
            # Sort values for better visualization
            df_count = df_agg.sort_values('count', ascending=True).reset_index(drop=True)

            # Define colors for each status
            color_scale = px.colors.qualitative.Plotly[:len(df_count)]

            # Plot the horizontal bar chart with colors
            fig_count = px.bar(
                df_count,
                x='count',
                y='status',
                orientation='h',  # Horizontal bar chart
                title=f"Order Status Breakdown for  {selected_date}",
                text='count',
                color='status',  # Use 'status' to assign a unique color to each bar
                color_discrete_sequence=color_scale  # Apply color scale
            )
            fig_count.update_traces(textposition='outside')  # Display count outside bars
            fig_count.update_layout(
                yaxis=dict(title="Order Status"),
                xaxis=dict(title="Count"),
                margin=dict(l=50, r=20, t=50, b=50)  # Adjust layout margins
            )

            # Convert the figure to HTML
            chart = pio.to_html(fig_count, full_html=False)
            return chart

    except (pg.Error, Exception) as e:
        print(f"Error in product function: {e}")
        return None



def productclass_overview(selected_date):
    try:
        # Execute query to fetch the count of records grouped by 'product class' for the given date
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT productclass.name AS productClassName, 
                    SUM(omtran.qty) AS total_qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                INNER JOIN productclass ON product.productclassid = productclass.id
                WHERE omdoc.invcdate::date = %s
                GROUP BY productclass.name;
                """,
                (selected_date,)
            )
            productclass_data = cursor.fetchall()

            # Create a DataFrame from the fetched data
            df_agg = pd.DataFrame(productclass_data, columns=['productclassname', 'total_qty'])

            # Sort values for better visualization
            df_count = df_agg.sort_values('total_qty', ascending=False).reset_index(drop=True).head(5)

            # Plot the count chart
            fig_count = px.pie(
                df_count,
                values='total_qty',
                names='productclassname',  # Correct column name
                title=f"Top 5 Product Class for {selected_date}",
                hole=0.3,
            )
            fig_count.update_traces(textposition='inside', textinfo='percent+label')

            # Convert the figure to HTML
            chart1 = pio.to_html(fig_count, full_html=False)
            return chart1

    except Exception as e:
        print(f"Error in product function: {e}")
        return None
    
def product_overview(selected_date):
    try:
        # Execute query to fetch the count of records grouped by 'product' for the given date
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT product.name AS productName, SUM(omtran.qty) AS total_qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                WHERE omdoc.invcdate::date = %s
                GROUP BY product.name;
                """,
                (selected_date,)
            )
            product_data = cursor.fetchall()

            # Create a DataFrame from the fetched data
            df_agg = pd.DataFrame(product_data, columns=['productname', 'total_qty'])

            # Sort values for better visualization
            df_count = df_agg.sort_values('total_qty', ascending=False).reset_index(drop=True).head(5)

            # Plot the count chart
            fig_count = px.pie(
                df_count,
                values='total_qty',
                names='productname',  # Correct column name
                title=f"Top 5 Product on {selected_date}",
                hole=0.3,
            )
            fig_count.update_traces(textposition='inside', textinfo='percent+label')

            # Convert the figure to HTML
            chart = pio.to_html(fig_count, full_html=False)
            return chart

    except Exception as e:
        print(f"Error in product function: {e}")
        return None

def top5_outlet_pie_chart(selected_date):
    try:
        # Execute query to fetch the 'total_invoice' grouped by 'outlet' for the given date
        with connection.cursor() as cursor:
            cursor.execute(
                 """
                SELECT 
                    outletname, 
                    SUM(totalinvc) AS total_invoice 
                FROM 
                    salessummary 
                WHERE 
                    invcdate::date = %s 
                GROUP BY 
                    outletname 
                ORDER BY 
                    total_invoice DESC 
                LIMIT 5;
                """,
                (selected_date,)
            )
            invoice_data = cursor.fetchall()

            # Create a DataFrame from the fetched data
            df_agg = pd.DataFrame(invoice_data, columns=['Outlet Name', 'Total Invoice'])

            # Plot the count chart
            fig_count = px.pie(
                df_agg,
                values='Total Invoice',
                names='Outlet Name',  
                title=f"Top 5 Outlets by Total Invoice on {selected_date}",
                hole=0.3,
            )
            fig_count.update_traces(textposition='inside', textinfo='percent+label')

            # Convert the figure to HTML
            chart = pio.to_html(fig_count, full_html=False)
            return chart

    except Exception as e:
        print(f"Error in product function: {e}")
        return None
    
def productclass_with_outlet_overview(selected_date):
    try:
        # Fetch necessary mappings
        with connection.cursor() as cursor:
            # Fetch outlet data
            cursor.execute("SELECT id, name FROM outlet")
            outlet_data = cursor.fetchall()
            column_outlet = [desc[0] for desc in cursor.description]
            df_outlet = pd.DataFrame(outlet_data, columns=column_outlet)
            list_of_outlet = dict(zip(df_outlet['id'], df_outlet['name']))

        # Query data based on the selected date
        with connection.cursor() as cursor:
            query = """
                SELECT productclass.name AS product_class,
                       omdoc.outletid,
                       omtran.qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                INNER JOIN productclass ON product.productclassid = productclass.id
                WHERE omdoc.invcdate::date = %s
            """
            cursor.execute(query, (selected_date,))
            result_data = cursor.fetchall()
            if not result_data:
                return "<p>No data found for the selected date: {}</p>".format(selected_date)

            # Create DataFrame from fetched data
            column_names = [desc[0] for desc in cursor.description]
            df = pd.DataFrame(result_data, columns=column_names)
            df['outlet'] = df['outletid'].map(list_of_outlet)

        # Aggregate data by product class and outlet
        df_agg = (
            df.groupby(['product_class', 'outlet'])
            .size()
            .reset_index(name='count')
            .sort_values(['product_class', 'count'], ascending=[True, False])
        )

        if df_agg.empty:
            return "<p>No data available to display chart.</p>"

        # Create grouped bar chart
        fig = px.bar(
            df_agg,
            x='product_class',
            y='count',
            color='outlet',
            title=f"Product Classes and  Their Best-Selling Outlets  on {selected_date}",
            labels={'product_class': 'Product Class', 'count': 'Count', 'outlet': 'Outlet'},
            barmode='group'  # Ensures bars are grouped by outlet for each product class
        )

        # Convert the figure to HTML
        chart = pio.to_html(fig, full_html=False)
        return chart

    except Exception as e:
        return f"<p>An error occurred: {e}</p>"


    
def dashboard1(request):
    assert isinstance(request, HttpRequest)
    
    date_form = DateSelectionForm(request.POST or None)

    if 'selected_date' not in request.session:
        request.session['selected_date'] = [None]

    if request.method == 'POST':
        print("POST data:", request.POST)
        
        # Handle DateSelectionForm
        if 'selected_date' in request.POST and date_form.is_valid():
            selected_date = date_form.cleaned_data['selected_date']
            request.session['selected_date'] = [selected_date]
            print(f"Selected date: {selected_date}")
    
    selected_date = request.session['selected_date'][0]

    chart = product(selected_date) if selected_date else None
    chart1 = payment(request)
    pos_html, pos_chart = pos(selected_date) if selected_date else None
    chart2 =  postfbtype_overview(selected_date) if selected_date else None
    chart3 = status_overview(selected_date) if selected_date else None
    chart4 = productclass_overview(selected_date) if selected_date else None
    chart5 = product_overview(selected_date) if selected_date else None
    chart6 = top5_outlet_pie_chart(selected_date) if selected_date else None
    chart7 = productclass_with_outlet_overview(selected_date) if selected_date else None

    return render(
        request, 'dashboard1.html', {
            'date': selected_date,
            'date_form': date_form,
            'product_chart': chart,
            'payment_type_chart': chart1,
            # 'pos': pos_html,
            'pos_chart': pos_chart,
            'order_chart' : chart2,
            'status_chart' : chart3,
            'productclassoverview_chart': chart4,
            'productoverview_chart' : chart5,
            'top5_outlet_pie_chart' : chart6,
            'productclass_with_outlet_overview' : chart7,
        }
    )

import plotly.graph_objects as go
import statsmodels.api as sm 
import numpy as np
from plotly.subplots import make_subplots

def data_getter(connection):

    with connection.cursor() as cursor:
        cursor.execute(
            """
            SELECT *
            FROM posopen
            INNER JOIN posopenomdoc
            ON posopen.id = posopenomdoc.posopenid
            INNER JOIN omdoc
            ON omdoc.id = posopenomdoc.omdocid
            INNER JOIN omtran
            ON omtran.omdocid = posopenomdoc.omdocid
            WHERE posopen.sessionclose::date != '0001-01-01' AND omtran.description != 'Testing Rounding'
            ORDER BY omdoc.invcdate::date
            """
        )

        data = cursor.fetchall()
            
        column_names = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(data, columns=column_names)

        return df

def linear_model():

    df = data_getter(connection)

    # Create new feature
    df['total revenue per product'] = df['salesprice'] * df['qty']

    # Define X and y
    X = df['total revenue per product']
    y = df['totalsub']

    # Add constant to X for OLS
    X = sm.add_constant(X)

    # Fit OLS model
    model = sm.OLS(y, X)
    result = model.fit()

    # Generate scatter plot with OLS trendline
    fig = px.scatter(
        df,
        x=df['total revenue per product'],
        y=df['totalsub'],
        opacity=0.65,
        trendline="ols",
        trendline_color_override="red"
    )

    # Update plot layout
    fig.update_layout(
        xaxis_title='Total Revenue per Product',
        yaxis_title='Total Sub',
        title='Regression Fit',
    )

    # Convert Plotly figure to HTML
    chart = pio.to_html(fig, full_html=False)

    # Generate summary as HTML
    summary = result.summary().as_html()

    return chart, summary

def plot_subplots():
    df = data_getter(connection)

    # Select only numeric columns and ensure 'totalsub' is included
    numeric_df = df[['totalinvc', 'qty', 'salesprice', 'totalsub']]

    # Create a 2x2 subplot figure with titles for each numeric column except 'totalsub'
    fig = make_subplots(
        rows=2,
        cols=2,
        subplot_titles=[col.capitalize() for col in numeric_df.columns if col != 'totalsub'],
    )

    for i, col in enumerate(numeric_df.columns):
        if col == 'totalsub':
            continue
        
        row = (i // 2) + 1 
        col_pos = (i % 2) + 1  
        
        fig.add_trace(
            go.Scatter(x=numeric_df[col], y=numeric_df['totalsub'], mode='markers', name=col),
            row=row,
            col=col_pos,
        )
        
        fig.update_xaxes(title_text=col.capitalize(), row=row, col=col_pos)
        fig.update_yaxes(title_text='Totalsub', row=row, col=col_pos)

    fig.update_layout(
        height=800,  
        width=1000,  
        showlegend=False,
        title_text="Scatter Plots for Numeric Columns",
        title_x=0.5,
        margin=dict(t=100, l=50, r=50, b=50) 
    )

    plot = pio.to_html(fig, full_html=False)

    return plot

def parallelCat():
    
    data = data_getter(connection)

    fig = px.parallel_categories(data)

    diagram = pio.to_html(fig, full_html=False)
    
    return diagram

def statistics(request):
    assert isinstance(request,HttpRequest)

    chart, summary = linear_model()
    chart1 = plot_subplots()
    diagram = parallelCat()
    payment_chart = payment(request)

    return render(
        request, 'statistics.html', {
            'title': 'Statistics',
            'chart': chart,
            'summary': summary,
            'chart1': chart1,
            'diagram': diagram,
            'payment_chart': payment_chart,
        }
    )


def sample(request):
    assert isinstance(request, HttpRequest)
    
    date_form = DateSelectionForm(request.POST or None)

    if 'selected_date' not in request.session:
        request.session['selected_date'] = [None]

    if request.method == 'POST':
        print("POST data:", request.POST)
        
        # Handle DateSelectionForm
        if 'selected_date' in request.POST and date_form.is_valid():
            selected_date = date_form.cleaned_data['selected_date']
            request.session['selected_date'] = [selected_date]
            print(f"Selected date: {selected_date}")
    
    selected_date = request.session['selected_date'][0]

    chart = product(selected_date) if selected_date else None
    chart1 = payment(request)
    pos_html, pos_chart = pos(selected_date) if selected_date else None
    chart2 =  postfbtype_overview(selected_date) if selected_date else None
    chart3 = status_overview(selected_date) if selected_date else None
    chart4 = productclass_overview(selected_date) if selected_date else None
    chart5 = product_overview(selected_date) if selected_date else None
    chart6 = top5_outlet_pie_chart(selected_date) if selected_date else None
    chart7 = productclass_with_outlet_overview(selected_date) if selected_date else None

    return render(
        request, 'sample.html', {
            'date': selected_date,
            'date_form': date_form,
            'product_chart': chart,
            'payment_type_chart': chart1,
            # 'pos': pos_html,
            'pos_chart': pos_chart,
            'order_chart' : chart2,
            'status_chart' : chart3,
            'productclassoverview_chart': chart4,
            'productoverview_chart' : chart5,
            'top5_outlet_pie_chart' : chart6,
            'productclass_with_outlet_overview' : chart7,
        }
    )