import os
import streamlit as st
import pandas as pd
import plotly.express as px
import psycopg2 as pg
from psycopg2 import Error
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Page configuration
st.set_page_config(
    page_title="Restaurant Dashboard",
    page_icon="🏂",
    layout="wide",
    initial_sidebar_state='expanded'
)

def get_connection():
    """
    Establish a database connection using environment variables.
    
    Returns:
        psycopg2.extensions.connection or None: Database connection
    """
    try:
        # Use environment variables for sensitive information
        conn = pg.connect(
            database=os.getenv('DB_NAME', 'Project'),
            user=os.getenv('DB_USER', 'postgres'),
            password=os.getenv('DB_PASSWORD', 'Nickson1234'),
            host=os.getenv('DB_HOST', '127.0.0.1'),
            port=os.getenv('DB_PORT', 5432),
        )
        return conn
    except (Error, Exception) as e:
        st.error(f"Error connecting to PostgreSQL: {e}")
        return None


def get_available_dates():
    """
    Retrieve distinct dates from the database.
    
    Returns:
        list: Sorted list of unique dates
    """
    conn = None
    try:
        conn = get_connection()
        if not conn:
            return []
        
        with conn.cursor() as cursor:
            cursor.execute('SELECT DISTINCT invcdate::date AS extracted_date FROM omdoc ORDER BY extracted_date')
            data = cursor.fetchall()
        
        return sorted([date[0] for date in data]) if data else []
    
    except Exception as e:
        st.error(f"Error retrieving dates: {e}")
        return []
    
    finally:
        if conn:
            conn.close()

def postfytype_detail(selected_date):
    """
    Generate a bar chart of counts by outlet city for a specific date and food/beverage type.
    
    Args:
        selected_date (date): The date to analyze
    
    Returns:
        pd.DataFrame or None: Aggregated data or None if error
    """
    conn = None
    try:
        conn = get_connection()
        
        if not conn:
            st.error("Failed to connect to the database.")
            return None

        # Fetch unique posfbtype values
        with conn.cursor() as cursor:
            cursor.execute("SELECT DISTINCT posfbtype FROM salessummary ORDER BY posfbtype")
            types = cursor.fetchall()
        
        # Convert to list of strings and handle empty case
        type_options = [t[0] for t in types] if types else []
        
        if not type_options:
            st.warning("No food/beverage types found in the database.")
            return None

        # Select food/beverage type with a default to the last item or 0 if empty
        x = st.selectbox(
            'Select order type', 
            type_options, 
            index=len(type_options)-1 if type_options else 0
        )

        # Execute query for the selected type and date
        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT outletcity, posfbtype, invcdate::date AS extracted_date "
                "FROM salessummary "
                "WHERE posfbtype = %s AND invcdate::date = %s;", 
                (x, selected_date)
            )
            product_data = cursor.fetchall()
            
            if not product_data:
                st.warning(f"No {x} data found for {selected_date}.")
                return None

            # Create DataFrame
            column_names = [desc[0] for desc in cursor.description]
            df = pd.DataFrame(product_data, columns=column_names)
            
            # Aggregate data
            df_agg = df.groupby('outletcity').size().reset_index(name='count')
            df_agg = df_agg.sort_values('count', ascending=False)
            
            # Create Plotly bar chart
            fig = px.bar(
                df_agg,
                x='outletcity',
                y='count',
                title=f"{x} Counts by Outlet City on {selected_date}",
                labels={
                    'outletcity': 'City', 
                    'count': f'{x} Count'
                },
                color='outletcity',
            )
            
            # Customize chart layout
            fig.update_layout(
                xaxis_title="Outlet City",
                yaxis_title=f"Number of {x} Orders"
            )
            
            # Display success message
            st.success(f"PostgreSQL data retrieved successfully for {selected_date}.")
            
            # Expandable detailed data view
            with st.expander("View Detailed Data"):
                st.dataframe(df_agg)
            
            # Display the chart
            st.plotly_chart(fig, use_container_width=True)

            return df_agg

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred: {e}")
        return None
    
    finally:
        # Ensure connection is closed
        if conn:
            conn.close()

def status_detail(selected_date):
    """
    Retrieve and visualize sales summary data for a specific date.
    
    Args:
        selected_date (date): The date to retrieve sales summary for
    
    Returns:
        pd.DataFrame or None: Sales summary data or None if error
    """
    conn = None
    try:
        conn = get_connection()

        if not conn:
            st.error("Failed to connect to the database.")
            return None

        with conn.cursor() as cursor:
            cursor.execute("SELECT DISTINCT status FROM salessummary")
            types = cursor.fetchall()
        
        # Convert to list of strings and handle empty case
        type_options = [t[0] for t in types] if types else []
        
        if not type_options:
            st.warning("No status found in the database.")
            return None

        # Select food/beverage type with a default to the last item or 0 if empty
        x = st.selectbox(
            'Select status type', 
            type_options, 
            index=len(type_options)-1 if type_options else 0
        )


        with conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT 
                    totalinvc,
                    status, 
                    invcdate::time AS extracted_time, 
                    invcdate::date AS extracted_date 
                FROM salessummary 
                WHERE invcdate::date = %s AND  status=%s
                ORDER BY invcdate::time;
                """,
                (selected_date,x,)
            )

            data = cursor.fetchall()

            if not data:
                st.warning(f"No sales summary data found for {selected_date}.")
                return None

            column_names = [desc[0] for desc in cursor.description]
            distribution = pd.DataFrame(data, columns=column_names)

            # Ensure extracted_time is in a proper time format
            distribution['extracted_time'] = pd.to_datetime(distribution['extracted_time'], format='%H:%M:%S').dt.time

            # Create area chart with proper grouping
            fig = px.area(
                distribution, 
                x='extracted_time', 
                y="totalinvc", 
                color='status',
                title=f"Sales Summary ({x}) for {selected_date}",
                labels={
                    'extracted_time': 'Time',
                    'totalinvc': 'Total Invoice',
                    'status': 'Status'
                }
            )

            # Improve chart readability
            fig.update_layout(
                xaxis_title='Time',
                yaxis_title='Total Invoice',
                legend_title='Status'
            )

            with st.expander("View Detailed Data"):
                st.dataframe(distribution)

            st.plotly_chart(fig, use_container_width=True)

            return distribution

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred while fetching sales summary data: {e}")
        return None
    
    finally:
        if conn:
            conn.close()



def postfytype_overview(selected_date):
    conn = None
    try:
        conn = get_connection()
        if not conn:
            st.error("Failed to connect to the database.")
            return None

        # Execute query to fetch the count of records grouped by 'posfbtype' for the given date
        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT posfbtype, count(*) AS count "
                "FROM salessummary "
                "WHERE invcdate::date = %s "
                "GROUP BY posfbtype;", 
                (selected_date,)
            )
            postfbtype_data = cursor.fetchall()
            
            # Convert to DataFrame
            df_count = pd.DataFrame(postfbtype_data, columns=['posfbtype', 'count'])
            
            # Sort values for better visualization
            df_count = df_count.sort_values('count', ascending=False).reset_index(drop=True)

            # Plot the count chart
            fig_count = px.pie(
                df_count,
                values='count',
                names='posfbtype',
                title="Order Type",
                hole=0.3,
            )
            fig_count.update_traces(textposition='inside', textinfo='percent+label')
            with st.expander("View Detailed Data"):
                st.dataframe(df_count)

            

            st.plotly_chart(fig_count, use_container_width=True)

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred: {e}")
        return None
    
    finally:
        # Ensure connection is closed
        if conn:
            conn.close()

def status_overview(selected_date):
    conn = None
    try:
        conn = get_connection()

        if not conn:
            st.error("Failed to connect to the database.")
            return None
        # The query filters by the specified date and groups the data by 'status'.
        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT status, count(*) AS count "
                "FROM salessummary "
                "WHERE invcdate::date = %s "
                "GROUP BY status;",
                (selected_date,)
            )
            status_data = cursor.fetchall()

            # Convert to DataFrame
            df_agg = pd.DataFrame(status_data, columns=['status', 'count'])
            
            # Sort data
            df_agg = df_agg.sort_values('count', ascending=False).reset_index(drop=True)

            # Define color scale (same as used in productClass_detail)
            color_scale = px.colors.qualitative.Plotly[:len(df_agg)]

            # Plot the count chart - Pie chart
            fig_count = px.pie(
                df_agg,
                values='count',
                names='status',
                title="Order Status Distribution",
                hole=0.3,
                color_discrete_sequence=color_scale
            )
            fig_count.update_traces(textposition='inside', textinfo='percent+label')
            with st.expander("View Detailed Data"):
                    st.dataframe(df_agg)

            st.plotly_chart(fig_count, use_container_width=True)

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred: {e}")
        return None
    
    finally:
        # Ensure connection is closed
        if conn:
            conn.close()

 


def productclass_detail(selected_date):
    conn = None
    try:
        # Establish database connection
        conn = get_connection()
        if not conn:
            st.error("Failed to connect to the database.")
            return None
        
        # Fetch and display product class options
        with conn.cursor() as cursor:
            cursor.execute("SELECT DISTINCT name FROM productclass ORDER BY name")
            types = cursor.fetchall()
        
        type_options = [t[0] for t in types] if types else []
        if not type_options:
            st.warning("No Product Class found in the database.")
            return None

        # Select product class
        x = st.selectbox(
            'Select Product class',
            type_options,
            index=len(type_options)-1 if type_options else 0
        )
        
        # Fetch necessary mappings
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM outlet")
            outlet_data = cursor.fetchall()
            column_outlet = [desc[0] for desc in cursor.description]
            df_outlet = pd.DataFrame(outlet_data, columns=column_outlet)
            list_of_outlet = dict(zip(df_outlet['id'], df_outlet['name']))
        
        # Query data based on selected product class and date
        with conn.cursor() as cursor:
            query = """
                SELECT omdoc.outletid, omdoc.invcdate::date AS extracted_date,
                       productclass.name AS productClassName, omtran.qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                INNER JOIN productclass ON product.productclassid = productclass.id
                WHERE productclass.name = %s AND omdoc.invcdate::date = %s
            """
            cursor.execute(query, (x, selected_date))
            productclass_data = cursor.fetchall()
            if not productclass_data: 
                st.warning(f"No {x} data found for {selected_date}.")
                return None

            # Process data
            column_names = [desc[0] for desc in cursor.description]
            df2 = pd.DataFrame(productclass_data, columns=column_names)
            df2['outlet'] = df2['outletid'].map(list_of_outlet)
                        
            # Group by outlet and count occurrences
            df_agg = (
                df2.groupby('outlet')
                .size()
                .reset_index(name='count')
                .sort_values('count', ascending=False)
                .reset_index(drop=True)  # Explicitly reset the index to follow 0, 1, 2, 3...
            )

            # Display chart
            if df_agg.empty:
                st.warning("No data available to display chart.")
            else:
                with st.expander("View Detailed Data"):
                    st.dataframe(df_agg)


                fig = px.bar(
                    df_agg,
                    x='outlet', 
                    y='count',
                    title=f"{x} Counts by Outlet City on {selected_date}",
                    labels={'outlet': 'City', 'count': f'{x}'},
                    color='outlet'
                )
                st.plotly_chart(fig)

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred: {e}")
        return None
    
    finally:
        if conn:
            conn.close()

def product_detail(selected_date):
    conn = None
    try:
        # Establish database connection
        conn = get_connection()
        if not conn:
            st.error("Failed to connect to the database.")
            return None
        
        # Fetch and display product options
        with conn.cursor() as cursor:
            cursor.execute("SELECT DISTINCT name FROM product ORDER BY name")
            types = cursor.fetchall()
        
        type_options = [t[0] for t in types] if types else []
        if not type_options:
            st.warning("No Product found in the database.")
            return None

        # Select product class
        x = st.selectbox(
            'Select Product ',
            type_options,
            index=len(type_options)-1 if type_options else 0
        )
        
        # Fetch necessary mappings
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM outlet")
            outlet_data = cursor.fetchall()
            column_outlet = [desc[0] for desc in cursor.description]
            df_outlet = pd.DataFrame(outlet_data, columns=column_outlet)
            list_of_outlet = dict(zip(df_outlet['id'], df_outlet['name']))

        
        # Query data based on selected product and date
        with conn.cursor() as cursor:
            query = """
                SELECT omdoc.outletid, omdoc.invcdate::date AS extracted_date,
                       product.name AS productName, omtran.qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                WHERE product.name = %s AND omdoc.invcdate::date = %s
            """
            cursor.execute(query, (x, selected_date))
            product_data = cursor.fetchall()
            if not product_data: 
                st.warning(f"No {x} data found for {selected_date}.")
                return None

            # Process data
            column_names = [desc[0] for desc in cursor.description]
            df= pd.DataFrame(product_data, columns=column_names)
            df['outlet'] = df['outletid'].map(list_of_outlet)
                        
            # Group by outlet and count occurrences
            df_agg = (
                df.groupby('outlet')
                .size()
                .reset_index(name='count')
                .sort_values('count', ascending=False)
                .reset_index(drop=True)  # Explicitly reset the index to follow 0, 1, 2, 3...
            )

            # Display chart
            if df_agg.empty:
                st.warning("No data available to display chart.")
            else:
                with st.expander("View Detailed Data"):
                    st.dataframe(df_agg)


                fig = px.bar(
                    df_agg,
                    x='outlet', 
                    y='count',
                    title=f"{x} Counts by Outlet City on {selected_date}",
                    labels={'outlet': 'City', 'count': f'{x} '},
                    color='outlet'
                )
                st.plotly_chart(fig)

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred: {e}")
        return None
    
    finally:
        if conn:
            conn.close()

def productclass_overview(selected_date):
    conn = None
    try:
        conn = get_connection()
        if not conn:
            st.error("Failed to connect to the database.")
            return None

        # Execute query for the selected type and date
        with conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT productclass.name AS productClassName, SUM(omtran.qty) AS total_qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                INNER JOIN productclass ON product.productclassid = productclass.id
                WHERE omdoc.invcdate::date = %s
                GROUP BY productclass.name;
                """,
                (selected_date,)
            )
            product_data = cursor.fetchall()
            
            # Convert to DataFrame
            df_agg = pd.DataFrame(product_data, columns=['productClassName', 'total_qty'])
            
            # Sort data and select top 5
            df_agg = df_agg.sort_values('total_qty', ascending=False).reset_index(drop=True).head(5)

            # Plot the count chart
            fig_count = px.pie(
                df_agg,
                values='total_qty',
                names='productClassName',
                title="Top 5 Categorical Products",
                hole=0.3,
            )
            fig_count.update_traces(textposition='inside', textinfo='percent+label')
            with st.expander("View Detailed Data"):
                st.dataframe(df_agg)



            st.plotly_chart(fig_count, use_container_width=True)

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred: {e}")
        return None
    
    finally:
        # Ensure connection is closed
        if conn:
            conn.close()


def product_overview(selected_date):
    conn = None
    try:
        conn = get_connection()
        if not conn:
            st.error("Failed to connect to the database.")
            return None

        # Execute query for the selected type and date
        with conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT product.name AS productName, SUM(omtran.qty) AS total_qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                WHERE omdoc.invcdate::date = %s
                GROUP BY product.name;
                """,
                (selected_date,)
            )
            product_data = cursor.fetchall()
            
            # Convert to DataFrame
            df_agg = pd.DataFrame(product_data, columns=['productName', 'total_qty'])
            
            # Sort data and select top 5
            df_agg = df_agg.sort_values('total_qty', ascending=False).reset_index(drop=True).head(5)

            # Plot the count chart
            fig_count = px.pie(
                df_agg,
                values='total_qty',
                names='productName',
                title="Top 5 Products",
                hole=0.3,
            )
            fig_count.update_traces(textposition='inside', textinfo='percent+label')
            with st.expander("View Detailed Data"):
               st.dataframe(df_agg)

            st.plotly_chart(fig_count, use_container_width=True)

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred: {e}")
        return None
    
    finally:
        # Ensure connection is closed
        if conn:
            conn.close()


def top5_outlet_pie_chart(selected_date):
    conn = None
    try:
        # Establish the connection
        conn = get_connection()
        if not conn:
            st.error("Failed to connect to the database.")
            return

        # Execute query to fetch top 5 outlets
        with conn.cursor() as cursor:
            cursor.execute(
                """
                SELECT 
                    outletname, 
                    SUM(totalinvc) AS total_invoice 
                FROM 
                    salessummary 
                WHERE 
                    invcdate::date = %s 
                GROUP BY 
                    outletname 
                ORDER BY 
                    total_invoice DESC 
                LIMIT 5;
                """,
                (selected_date,)
            )
            data = cursor.fetchall()

        # Convert to a DataFrame
        df = pd.DataFrame(data, columns=['Outlet Name', 'Total Invoice'])

        # Create a pie chart
        fig = px.pie(
            df, 
            values='Total Invoice', 
            names='Outlet Name', 
            title="Top 5 Outlets by Total Invoice",
            hole=0.3
        )
        fig.update_traces(textposition='inside', textinfo='percent+label')
        with st.expander("View Detailed Data"):
            st.dataframe(df)


        st.plotly_chart(fig, use_container_width=True)

    except Exception as e:
        st.error(f"An error occurred: {e}")
    finally:
        if conn:
            conn.close()



def outlet(selected_date):
    conn = None
    try:
        # Establish database connection
        conn = get_connection()
        if not conn:
            st.error("Failed to connect to the database.")
            return None
        
        # Fetch and display outlet options
        with conn.cursor() as cursor:
            cursor.execute("SELECT DISTINCT name FROM outlet ORDER BY name")
            types = cursor.fetchall()
        
        type_options = [t[0] for t in types] if types else []
        if not type_options:
            st.warning("No outlet found in the database.")
            return None

        # Select outlet
        x = st.selectbox(
            'Select Outlet',
            type_options,
            index=len(type_options)-1 if type_options else 0
        )

            
    
        
        # Query data based on selected outlet and date
        with conn.cursor() as cursor:
            query = """
                SELECT omdoc.outletid, omdoc.invcdate::date AS extracted_date,
                    product.name AS productName, omtran.qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code

                INNER JOIN outlet ON omdoc.outletid = outlet.id
                WHERE outlet.name = %s AND omdoc.invcdate::date = %s
            """
            cursor.execute(query, (x, selected_date))
            outlet_data = cursor.fetchall()
            if not outlet_data: 
                st.warning(f"No {x} data found for {selected_date}.")
                return None

            # Process data
            column_names = [desc[0] for desc in cursor.description]
            df= pd.DataFrame(outlet_data, columns=column_names)

            df_agg = (
                df.groupby('productname')
                .size()
                .reset_index(name='count')
                .sort_values('count', ascending=False)
                .reset_index(drop=True)  # Explicitly reset the index to follow 0, 1, 2, 3...
            )

            # Display chart
            if df_agg.empty:
                st.warning("No data available to display chart.")
            else:
                with st.expander("View Detailed Data"):
                    st.dataframe(df_agg)


                fig = px.bar(
                    df_agg,
                    x='productname', 
                    y='count',
                    title=f"Product sells by {x} on {selected_date}",
                    labels={'productname': 'Product', 'count': 'Count'},
                    color='productname'
                )
                st.plotly_chart(fig)
        # Query data based on selected product class and date
        with conn.cursor() as cursor:
            query = """
                SELECT omdoc.outletid, omdoc.invcdate::date AS extracted_date,
                    productclass.name AS productClassName, omtran.qty
                FROM omtran
                INNER JOIN omdoc ON omtran.omdocid = omdoc.id
                INNER JOIN product ON omtran.productcode = product.code
                INNER JOIN productclass ON product.productclassid = productclass.id
                INNER JOIN outlet ON omdoc.outletid = outlet.id
                WHERE outlet.name = %s AND omdoc.invcdate::date = %s
            """
            cursor.execute(query, (x, selected_date))
            result = cursor.fetchall()
            if not result: 
                st.warning(f"No {x} data found for {selected_date}.")
                return None

            # Process data
            column_names = [desc[0] for desc in cursor.description]
            df2 = pd.DataFrame(result, columns=column_names)



                        

            df_agg = (
                df2.groupby('productclassname')
                .size()
                .reset_index(name='count')
                .sort_values('count', ascending=False)
                .reset_index(drop=True)  # Explicitly reset the index to follow 0, 1, 2, 3...
            )

            # Display chart
            if df_agg.empty:
                st.warning("No data available to display chart.")
            else:
                with st.expander("View Detailed Data"):
                    st.dataframe(df_agg)


                fig = px.bar(
                    df_agg,
                    x='productclassname', 
                    y='count',
                    title=f"Categorical Product sales at  {x} on {selected_date}",
                    labels={'productclassname': 'Product Class', 'count': 'Count'},
                    color='productclassname'
                )
                st.plotly_chart(fig)
        
            

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred: {e}")
        return None
    
    finally:
        if conn:
            conn.close()

def paymentCount():
    """
    Generate a pie chart for payment type counts and display detailed data.
    
    Returns:
        DataFrame: DataFrame containing payment counts by type.
    """
    conn = None
    try:
        conn = get_connection()

        if not conn:
            st.error("Failed to connect to the database.")
            return None

        # Fetch tender types
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM tendertype")
            data = cursor.fetchall()

            if not data:
                st.warning("No tender type data fetched from the database.")
                return None

            column_names = [desc[0] for desc in cursor.description]
            tender_df = pd.DataFrame(data, columns=column_names)

            # Create a dictionary mapping tender type IDs to names
            list_of_payment = dict(zip(tender_df['id'], tender_df['name']))

        # Fetch payment counts
        with conn.cursor() as cursor:
            cursor.execute(
                "SELECT tendertypeid, COUNT(*) as count "
                "FROM ompayment "
                "WHERE tendertypeid IS NOT NULL "
                "GROUP BY tendertypeid "
                "ORDER BY count DESC "
                "LIMIT 5;"
            )
            product_data = cursor.fetchall()

            if not product_data:
                st.warning("No payment data fetched from the database.")
                return None

            column_names = [desc[0] for desc in cursor.description]
            df = pd.DataFrame(product_data, columns=column_names)

            # Replace tender type IDs with their names
            df['tendertypename'] = df['tendertypeid'].map(list_of_payment)

            # Create DataFrame for count
            df_count = df[['tendertypename', 'count']]

            # Plot the count chart
            fig_count = px.pie(
                df_count,
                values='count',
                names='tendertypename',
                title="Payment Method (Count) - Top 5",
                hole=0.3,
            )
            fig_count.update_traces(textposition='inside', textinfo='percent+label')

            # Display the detailed data
            st.write("##### Payment Type Distribution by Count")
            with st.expander("View Detailed Data (Count)"):
                st.dataframe(df_count)

            st.success("Connection to PostgreSQL established successfully.")
            st.plotly_chart(fig_count, use_container_width=True)

            return df_count

    except (pg.Error, Exception) as e:
        st.error(f"An error occurred while fetching payment data: {e}")
        return None

    finally:
        if conn:
            conn.close()


def main():
    """
    Main function to set up the Streamlit dashboard.
    """
    # Sidebar navigation
    with st.sidebar:
        st.title('🏂 Restaurant Dashboard')

        # Navigation Options
        menu = st.radio(
            "Navigate", 
            options=["Data Overview","Order Data Detail","Product Data Detail","Payment Data Overview"], 
            index=0, 
            key="navigation_menu"
        )

    # Handle navigation based on the selected menu
    if menu == "Data Overview":
        data_overview()
    elif menu == "Product Data Detail":
        product_data_detail()
    elif menu =="Payment Data Overview":
        payment_data_overview() 
    else :
        order_data_detail() 
def data_overview():
    # Fetch available dates
    dates = get_available_dates()
    
    if not dates:
        st.error("No dates found in the database.")
        return
    
    # Add date filter here
    selected_date = st.selectbox(
        'Select a date for Data Overview', 
        dates, 
        index=len(dates)-1 if dates else 0,
        key="order_data_date_select"  # Unique key for this selectbox
    )
    
    # Display results for the selected date
    st.write(f"Selected Date: {selected_date}")
    col = st.columns((3, 3.5,3), gap='medium')  # Add a fourth column
    with col[0]:
        top5_outlet_pie_chart(selected_date)
        postfytype_overview(selected_date)
    with col[1]:
        productclass_overview(selected_date)
        status_overview(selected_date)
    with col[2]:
        product_overview(selected_date)

def order_data_detail():

    """
    Order Data Overview: Displays postfytype and status for the selected date.
    """
    st.write("### Order Data Detail")
    
    # Fetch available dates
    dates = get_available_dates()
    
    if not dates:
        st.error("No dates found in the database.")
        return
    
    # Add date filter here
    selected_date = st.selectbox(
        'Select a date for Order Data Detail', 
        dates, 
        index=len(dates)-1 if dates else 0,
        key="order_data_date_select"  # Unique key for this selectbox
    )
    
    # Display results for the selected date
    st.write(f"Selected Date: {selected_date}")
    
    col = st.columns((3, 3.5), gap='medium')  # Add a fourth column
    with col[0]:
        postfytype_detail(selected_date)
    with col[1]:
        status_detail(selected_date)




def payment_data_overview():    
    st.markdown("### Payment Data Overview")
    paymentCount()



def product_data_detail():
    st.markdown("### Product Data Detail ")

    
    # Fetch available dates
    dates = get_available_dates()
    
    if not dates:
        st.error("No dates found in the database.")
        return
    
    # Add date filter here
    selected_date = st.selectbox(
        'Select a date for Product Data Detail', 
        dates, 
        index=len(dates)-1 if dates else 0,
        key="order_data_date_select"  # Unique key for this selectbox
    )
    
    # Display results for the selected date
    st.write(f"Selected Date: {selected_date}")
    
    col = st.columns((3, 3.5, 3,), gap='medium')  # Add a fourth column
    with col[0]:
        productclass_detail(selected_date)
    with col[1]:  # Now col[3] exists
        product_detail(selected_date)
    with col[2]:
        outlet(selected_date)

        
 

# Run the main function
if __name__ == "__main__":
    main()





