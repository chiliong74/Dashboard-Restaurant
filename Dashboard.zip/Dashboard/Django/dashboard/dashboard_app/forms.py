from django import forms
from django.db import connection


class BaseDateForm:
    """Base class for forms that need date choices from the database"""
    def get_date_choices(self):
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT DISTINCT 
                    to_char(invcdate, 'YYYY-MM-DD') AS formatted_date
                    FROM omdoc
                    ORDER BY formatted_date
                """)
                dates = cursor.fetchall()
            return [(date[0], date[0]) for date in dates] if dates else []
        except Exception as e:
            print(f"Error fetching date choices: {e}")
            return []

class DateSelectionForm(BaseDateForm, forms.Form):
    selected_date = forms.ChoiceField(choices=[], label="Select Date", required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['selected_date'].choices = self.get_date_choices()

class PosFbTypeForm(BaseDateForm, forms.Form):
    selected_posfbtype = forms.ChoiceField(choices=[], label="Select POS Type",required=False)
    selected_date = forms.ChoiceField(widget=forms.HiddenInput(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['selected_posfbtype'].choices = self.get_posfbtype_choices()
        self.fields['selected_date'].choices = self.get_date_choices()

    def get_posfbtype_choices(self):
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT DISTINCT posfbtype 
                    FROM salessummary 
                    ORDER BY posfbtype
                """)
                types = cursor.fetchall()
            return [(t[0], t[0]) for t in types] if types else []
        except Exception as e:
            print(f"Error fetching posfbtype choices: {e}")
            return []

class TypeForm(BaseDateForm, forms.Form):
    selected_type = forms.ChoiceField(choices=[], label="Select Type",required=False)
    selected_date = forms.ChoiceField(widget=forms.HiddenInput(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['selected_type'].choices = self.get_choices()
        self.fields['selected_date'].choices = self.get_date_choices()

    def get_choices(self):
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT DISTINCT status FROM salessummary")
                types = cursor.fetchall()
            return [(t[0], t[0]) for t in types] if types else []
        except Exception as e:
            print(f"Error fetching status choices: {e}")
            return []

class ProductClassFilterForm(BaseDateForm, forms.Form):
    selected_productclass = forms.ChoiceField(choices=[], label="Select Product Class ", required=False)
    selected_date = forms.ChoiceField(widget=forms.HiddenInput(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['selected_productclass'].choices = self.get_product_class_choices()
        self.fields['selected_date'].choices = self.get_date_choices()

    def get_product_class_choices(self):
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT DISTINCT name FROM productclass  ORDER BY name
                """)
                types = cursor.fetchall()
            return [(t[0], t[0]) for t in types] if types else []
        except Exception as e:
            print(f"Error fetching product class choices: {e}")
            return []

class productForm(BaseDateForm, forms.Form):
    selected_product = forms.ChoiceField(choices=[], label="Select Product ", required=False)
    selected_date = forms.ChoiceField(widget=forms.HiddenInput(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['selected_product'].choices = self.get_product_choices()
        self.fields['selected_date'].choices = self.get_date_choices()

    def get_product_choices(self):
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT DISTINCT name FROM product ORDER BY name
                """)
                types = cursor.fetchall()
            return [(t[0], t[0]) for t in types] if types else []
        except Exception as e:
            print(f"Error fetching product  choices: {e}")
            return []
        
class outletForm(BaseDateForm, forms.Form):
    selected_outlet = forms.ChoiceField(choices=[], label="Select Outlet ", required=False)
    selected_date = forms.ChoiceField(widget=forms.HiddenInput(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['selected_outlet'].choices = self.get_outlet_choices()
        self.fields['selected_date'].choices = self.get_date_choices()

    def get_outlet_choices(self):
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT DISTINCT name FROM outlet ORDER BY name
                """)
                types = cursor.fetchall()
            return [(t[0], t[0]) for t in types] if types else []
        except Exception as e:
            print(f"Error fetching product  choices: {e}")
            return []

class outletForm2(BaseDateForm, forms.Form):
    selected_outlet2 = forms.ChoiceField(choices=[], label="Select Outlet ", required=False)
    selected_date = forms.ChoiceField(widget=forms.HiddenInput(), required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['selected_outlet2'].choices = self.get_outlet_choices()
        self.fields['selected_date'].choices = self.get_date_choices()

    def get_outlet_choices(self):
        try:
            with connection.cursor() as cursor:
                cursor.execute("""
                    SELECT DISTINCT name FROM outlet ORDER BY name
                """)
                types = cursor.fetchall()
            return [(t[0], t[0]) for t in types] if types else []
        except Exception as e:
            print(f"Error fetching product  choices: {e}")
            return []